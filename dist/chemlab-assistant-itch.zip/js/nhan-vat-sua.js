/* =====================================================================
   SỬA HÌNH GỐC NHÂN VẬT — vá lên HD_CHARS (do-hoa.js) lúc khởi động, không sửa file hình gốc.
   Nạp SAU js/do-hoa.js, TRƯỚC js/nhan-vat-skin.js. nhan-vat-skin.js gọi suaHinhGoc(svg, i) cho từng hình
   (i = chỉ số HD_CHARS: 0 giáo sư, 1..10 khách) NGAY SAU khi đã thay mắt chấm (nhóm <g class="eyes2"> là phần tử
   cuối của svg), TRƯỚC khi ghép trang phục (skin) và đạo cụ.

   Lưu ý thứ tự lớp: sau nhóm eyes2 còn đồ của diversify (cổ áo, tạp dề… trong nhan-vat.js). Lớp "over" của skin
   được chèn ngay trước <g class="eyes2 — tức NẰM TRÊN mọi thứ ta chèn ở đây bằng chenTruocMat().
   Mọi id thêm mới bắt đầu bằng 'sua<i>_'. Toạ độ khung 200x280 (khách 4..10): mặt x 72..168, đỉnh đầu y≈54,
   mắt y≈102, cổ y 150–184, vai y≈196. Trong lab hình bị bàn che dưới y = 226.

   Những gì đã vá:
     4  Anh Minh : bỏ chỏm tóc nhọn chọc xuyên đỉnh mũ bảo hộ (giữ tóc mai dưới vành mũ).
     6  Ông Sáu  : bỏ nét cung lơ lửng trên đầu hói; áo gi-lê nâu → xanh ô-liu (màu nhận diện của ông); nới khoét cổ áo.
     8  Chị Hoa  : bỏ ngôi sao đỏ trên trán + cục đỏ trên đỉnh tóc; cài một bông hoa 5 cánh trên tai trái; cổ thon lại.
     10 Cô Mai   : làm lại tóc nữ (mái lệch + tóc phồng ôm mặt + đuôi ngựa thấp vắt qua vai phải, dây buộc đỏ
                   san hô, kẹp tóc xanh lá dứa), lông mày mảnh, bông tai vàng có hạt san hô, áo cánh trắng → hồng đào.
     3  Bé Na    : bỏ cà vạt raster (lộ ra khi khăn quàng đã thu nhỏ).
   (Khăn quàng đỏ Bé Na / Bạn Tí và con cá của Ông Sáu là đạo cụ: sửa trong CUST_PROPS cuối do-hoa.js.)
   ===================================================================== */
'use strict';

const SUA_INK = '#3b3025';

// tìm phần tử tự đóng (<… />) có chứa chuỗi kim; trả về [đầu, cuối] hoặc null
function suaTimPhanTu(svg, kim){
  const k = svg.indexOf(kim);
  if(k < 0) return null;
  const a = svg.lastIndexOf('<', k), b = svg.indexOf('/>', k);
  return (a < 0 || b < 0) ? null : [a, b + 2];
}
// bỏ MỌI phần tử tự đóng có chứa kim
function suaBo(svg, kim){
  let r;
  while((r = suaTimPhanTu(svg, kim))) svg = svg.slice(0, r[0]) + svg.slice(r[1]);
  return svg;
}
// thay phần tử đầu tiên có chứa kim bằng chuỗi moi (không thấy thì để nguyên)
function suaThay(svg, kim, moi){
  const r = suaTimPhanTu(svg, kim);
  return r ? svg.slice(0, r[0]) + moi + svg.slice(r[1]) : svg;
}
// chèn lên trên quần áo + tay, dưới mắt (và dưới lớp over của skin)
function suaChenTruocMat(svg, s){
  const e = svg.indexOf('<g class="eyes2');
  return e >= 0 ? svg.slice(0, e) + s + svg.slice(e) : svg.replace('</svg>', s + '</svg>');
}
// đổi màu các điểm dừng của gradient (cả bản 'hdN_' lẫn 'hdNe_'), giữ nguyên offset
function suaDoiMau(svg, hd, duoi, mau){
  [hd + '_', hd + 'e_'].forEach(pre => {
    const re = new RegExp('(<(linear|radial)Gradient id="' + pre + duoi + '"[^>]*>)([\\s\\S]*?)(</\\2Gradient>)');
    svg = svg.replace(re, (all, mo, loai, than, dong) => {
      let n = 0;
      than = than.replace(/stop-color(="|:)(#[0-9a-fA-F]{3,8}|rgb\([^)]*\))/g, (m, sep) => 'stop-color' + sep + mau[Math.min(n++, mau.length - 1)]);
      return mo + than + dong;
    });
  });
  return svg;
}

const SUA = {
  /* ---------- 3 · Bé Na: bỏ cà vạt (ảnh raster #hd3__Image15) ----------
     Trước đây khăn quàng to che luôn cà vạt; nay khăn quàng thu nhỏ (CUST_PROPS[2]) nên cà vạt lộ ra,
     trông như dân văn phòng — bỏ hẳn. Cổ áo (#hd3__Image14) cũng bỏ: đó là một mảng bóng raster mờ, không có
     cà vạt thì nó thành vệt xám nhoè hai bên nút khăn quàng. */
  3(svg){
    svg = suaBo(svg, 'xlink:href="#hd3__Image15"');
    return suaBo(svg, 'xlink:href="#hd3__Image14"');
  },

  /* ---------- 4 · Anh Minh: tóc chỉ còn phần dưới mũ ----------
     Tóc sau gáy (path 'M62,96 q-10,-44 26,-58 …') có 8 chỏm nhọn lên tới y≈20, cao hơn đỉnh mũ (y≈28):
     thay dãy chỏm bằng một đường cong thấp nằm gọn dưới vòm mũ. Phần lởm chởm hai bên thái dương giữ nguyên. */
  4(svg){
    // mép trái tóc cũng phồng ra ngoài vòm mũ (x≈57 ở y≈70): kéo vào sát đầu, phần dưới vành vẫn lộ tóc mai
    svg = svg.replace('d="M62,96 q-10,-44 26,-58 q-6,-10', 'd="M62,96 q0,-24 6,-36 q6,-14 20,-22 q-6,-10');
    return svg.replace('q-6,-10 6,-14 q4,10 10,4 q2,-12 12,-8 q0,10 8,6 q6,-10 14,0 q-4,8 4,8 q10,-6 14,4 q-8,4 -2,10',
                       'q30,-12 60,0 q8,4 6,10');
  },

  /* ---------- 6 · Ông Sáu ---------- */
  /* ---------- 1 · Bà Tư: bỏ hàng khuy vàng nhỏ trên áo (một khuy lòi ra ngay dưới quai túi bánh mì) ---------- */
  1(svg){
    return svg.split('fill:rgb(232,184,75);stroke:rgb(59,48,37);stroke-width:1.6px').join('fill:none;stroke:none;stroke-width:1.6px');
  },

  /* ---------- 7 · Bạn Tí: mặt đã hạ thấp (FACE_META.small) nên mũi bắt đầu thấp hơn, nhưng nét cánh mũi vẫn ở y 130 —
     cắt ngang giữa mũi thành dấu chéo. Dời nét cánh mũi xuống sát chân mũi mới. ---------- */
  7(svg){
    return svg.replace('<path d="M113,130 q7,4 14,0" stroke-width="1.8"', '<path d="M115,139 q5,3 10,0" stroke-width="1.8"');
  },

  /* ---------- 5 · Cô Lan: lòng chữ V của cổ áo — nửa trái tô gradient tay áo (xanh tối), nửa phải màu kem → trông như
     hai mảnh vải khác nhau. Cả hai nửa là áo lót kem (bộ scrubs đổi cả hai sang xanh, xem trang-phuc.js). ---------- */
  5(svg){
    return svg.replace('<path fill="url(#hd5_c4clothL)" d="M120,176 q-14,2 -26,13 q19,-3 26,7z"', '<path fill="#f3eddc" d="M120,176 q-14,2 -26,13 q19,-3 26,7z"');
  },

  6(svg){
    // (a) nét cung mờ lơ lửng phía trên đỉnh đầu hói
    svg = suaBo(svg, 'd="M108,48 q10,-6 18,0"');
    // (b) gi-lê + hai ống tay: nâu → xanh ô-liu
    svg = suaDoiMau(svg, 'hd6', 'c5cloth',  ['#8d9a55', '#74803f']);
    svg = suaDoiMau(svg, 'hd6', 'c5clothL', ['#74803f', '#5a6430']);
    // (c) bỏ râu quai nón
    svg = suaBo(svg, 'd="M84,138 q-6,26 6,44');
    // (d) bỏ vành tóc bạc ôm sau tai (trông như cái chụp tai); thu thành chỏm thì lại thành tai nhọn — để hói hẳn
    svg = suaBo(svg, 'd="M60,132 q-10,-18 4,-32');
    svg = suaBo(svg, 'd="M180,132 q10,-18 -4,-32');
    // (e) cổ (x 102..138 ở chân) rộng hơn khoét cổ áo (x 104..136) nên hai mép cổ đè lên vai áo: nới khoét cổ ra x 98..142
    svg = svg.replace('d="M104,176 q-32,9 -46,30', 'd="M98,176 q-26,9 -40,30').replace('q-14,-21 -46,-30 q-14,8 -32,0z', 'q-14,-21 -40,-30 q-22,9 -44,0z');
    svg = svg.replace('d="M104,176 q-14,4 -26,14 l0,110 l40,0 l0,-118 q-7,-4 -14,-6z', 'd="M98,176 q-10,4 -20,14 l0,110 l40,0 l0,-118 q-10,-5 -20,-6z');
    svg = svg.replace('d="M136,176 q14,4 26,14 l0,110 l-40,0 l0,-118 q7,-4 14,-6z', 'd="M142,176 q10,4 20,14 l0,110 l-40,0 l0,-118 q10,-5 20,-6z');
    return svg;
  },

  /* ---------- 8 · Chị Hoa: hoa cài tóc thay cho "lá phong" đỏ ---------- */
  8(svg){
    // miếng lót cổ chữ V (đồ của diversify, nằm SAU nhóm mắt nên đè lên mọi lớp trang phục) dời xuống dưới lớp 'over'
    // của skin: ve vest và dây chuyền kẹp trong vest phải nằm trên nó
    const v = suaTimPhanTu(svg, 'd="M98,178 L120,212 L142,178');
    if(v){ const el = svg.slice(v[0], v[1]); svg = suaChenTruocMat(svg.slice(0, v[0]) + svg.slice(v[1]), el); }
    // cổ thon lại (x 106..134) để nằm gọn trong khoét cổ áo (x 108..132) thay vì tràn ra hai mép vai
    svg = svg.replace('d="M100,150 q20,10 40,0 l-2,34 q-18,9 -36,0 z"', 'd="M106,150 q14,8 28,0 l-1,32 q-13,7 -26,0 z"');
    svg = svg.replace('d="M102,152 q18,8 36,0 l-1,11 q-17,7 -34,0 z"', 'd="M107,152 q13,6 26,0 l-1,10 q-12,6 -24,0 z"');
    svg = suaBo(svg, 'd="M126,38 q-6,-8 4,-12');                 // cục đỏ hình tim trên đỉnh tóc
    svg = suaBo(svg, 'd="M96,66 l14,-4 l0,6 l14,2');             // ngôi sao đỏ trên trán (diversify đã nudge lên)
    svg = suaBo(svg, '<circle cx="102" cy="64" r="3" fill="#d9634f"');   // nhuỵ của ngôi sao
    // bông hoa 5 cánh tròn, nhuỵ vàng, cài ở mép tóc trái ngay trên tai
    const cx = 65, cy = 71, r = 5.6, d = 6.2;
    let canh = '';
    for(let k = 0; k < 5; k++){
      const a = (-90 + k * 72) * Math.PI / 180;
      canh += '<circle cx="' + (cx + d * Math.cos(a)).toFixed(1) + '" cy="' + (cy + d * Math.sin(a)).toFixed(1) + '" r="' + r + '"/>';
    }
    const hoa = '<g class="sua8_hoa" transform="rotate(-12 ' + cx + ' ' + cy + ')">'
      + '<path d="M59,79 q-7,3 -7,10 q7,-2 9,-8z M58,70 q-8,-3 -12,2 q6,4 12,1z" fill="#6ea85a" stroke="' + SUA_INK + '" stroke-width="1.6" stroke-linejoin="round"/>'
      + '<g fill="#e8605a" stroke="' + SUA_INK + '" stroke-width="2">' + canh + '</g>'
      + '<g fill="#e8605a">' + canh.replace(/r="[\d.]+"/g, 'r="' + (r - 1.1) + '"') + '</g>'   // xoá nét mực giữa các cánh chồng nhau
      + '<circle cx="' + cx + '" cy="' + cy + '" r="3.4" fill="#f5c842" stroke="' + SUA_INK + '" stroke-width="1.6"/>'
      + '</g>';
    return suaChenTruocMat(svg, hoa);
  },

  /* ---------- 10 · Cô Mai: tóc nữ, lông mày mảnh, bông tai, áo hồng đào ---------- */
  10(svg){
    const H = 'url(#hd10_c9hair)';
    // tóc sau (nằm sau mặt + tai, trong nhóm biến đổi của khuôn mặt nên vẽ theo toạ độ gốc: mặt x 72..168, đỉnh y 54):
    // khối tóc phồng ôm đầu, hai bên rủ xuống ngang hàm (y≈132) — dáng đầu khác hẳn tóc ngắn của Thầy Nam
    svg = suaThay(svg, 'd="M62,98 q-12,-42 26,-56 q28,-18 56,-2',
      '<path fill="' + H + '" d="M68,134 q-14,-26 -9,-58 q8,-42 61,-42 q53,0 61,42 q5,32 -9,58 q-6,4 -12,0 q-34,-12 -80,0 q-6,4 -12,0z"/>'
      + '<path d="M88,44 q32,-12 64,0" fill="none" stroke="#7a6a5c" stroke-width="2" opacity=".5"/>');
    svg = suaBo(svg, 'd="M70,70 l14,-6 l2,6 l-14,6z"');          // kẹp đỏ cũ
    // mái lệch: ngôi ở x≈142, mái chính hất sang trái tới thái dương, một lọn nhỏ hất sang phải.
    // Mép dưới mái cao hơn lông mày ≥ 8 đơn vị — băng đô của skin 1 (y 57–83) đè lên vẫn gọn.
    svg = suaThay(svg, 'd="M74,66 q22,-16 46,-2 q4,6 -4,10',
      '<path fill="' + H + '" d="M142,56 q-26,6 -44,18 q-14,6 -24,22 q-6,-24 0,-36 q16,-22 52,-20 q12,2 16,16z"/>'
      + '<path fill="' + H + '" d="M142,56 q16,0 24,16 q4,10 2,20 q-6,-14 -14,-20 q-8,-6 -12,-16z"/>'
      + '<path d="M132,59 q-24,6 -40,20 M150,60 q8,4 12,12" fill="none" stroke="#7a6a5c" stroke-width="1.6" opacity=".55"/>'
      // kẹp tóc xanh lá dứa trên mái trái, cao hơn băng đô của skin 1 để không bị che dở dang
      + '<g transform="rotate(-22 96 52)"><rect x="88" y="49.6" width="16" height="4.8" rx="2.4" fill="#7cc3a4" stroke="' + SUA_INK + '" stroke-width="1.6"/>'
      + '<circle cx="92" cy="51.2" r="0.9" fill="#fff" stroke="none"/></g>');
    // lông mày mảnh, cong (bản 'thin' của nhan-vat.js vẫn đậm như lông mày đàn ông)
    svg = svg.split('M82,86 q18,-10 32,-3 q-3,5 -15,3 q-11,-1 -17,0z').join('M84,86 q14,-10 30,-4 q-15,-2 -30,4z');
    // áo cánh trắng → hồng đào / san hô (thân sáng hơn, tay phải tối hơn); cổ áo phải đi theo gradient áo để skin đổi màu được
    svg = suaDoiMau(svg, 'hd10', 'c9cloth',  ['#f6b49c', '#ea9a7e']);
    svg = suaDoiMau(svg, 'hd10', 'c9clothL', ['#ea9a7e', '#d47f63']);
    svg = svg.replace('<path fill="#f3eddc" d="M120,176 q14,2 26,13', '<path fill="url(#hd10_c9cloth)" d="M120,176 q14,2 26,13');
    // đuôi ngựa thấp: túm sau tai phải, buộc dây san hô, rủ qua vai phải ra trước ngực (đuôi tóc y≈222 < 226)
    const duoi = '<g class="sua10_toc" stroke="' + SUA_INK + '" stroke-linejoin="round" stroke-linecap="round">'
      + '<path fill="' + H + '" stroke-width="2.8" d="M163,142 q-8,18 -6,36 q2,18 -3,30 q-2,8 -7,14 q13,-1 19,-14 q8,-16 6,-34 q-1,-18 5,-32z"/>'
      + '<path d="M168,150 q-6,24 -2,44 q1,10 -4,18" fill="none" stroke="#7a6a5c" stroke-width="1.5" opacity=".55"/>'
      + '<path d="M162,140 q4,-6 16,-2 q2,6 -2,8 q-8,3 -14,-1 q-2,-2 0,-5z" fill="#e0604c" stroke-width="2"/>'
      + '<path d="M166,141 v4 M171,140 v5" fill="none" stroke="#a8402f" stroke-width="1.2" opacity=".8"/>'
      // bông tai: nụ vàng + hạt san hô
      + '<g stroke-width="1.4"><path d="M61,121 v4 M179,121 v4" fill="none"/>'
      + '<circle cx="61" cy="121" r="2" fill="#f2c94c"/><circle cx="179" cy="121" r="2" fill="#f2c94c"/>'
      + '<circle cx="61" cy="128" r="2.8" fill="#ef8a6f"/><circle cx="179" cy="128" r="2.8" fill="#ef8a6f"/></g>'
      + '</g>';
    return suaChenTruocMat(svg, duoi);
  }
};

/* Vá chung cho mọi hình (chạy trước SUA[i]):
   • mảng bóng má trái 'M80,122 …' (mực mờ 7%) không theo khuôn mặt khi mặt bị thu hẹp / đổi khung, nên lòi ra ngoài
     hàm thành một vệt xám (Bạn Tí, Chị Hoa, Thầy Nam, Chú Ba, Bé Na…) — bỏ đi;
   • quai nón lá của Chú Ba (nét đỏ 'M71.8,76C66.726,96.067…') nằm SAU khuôn mặt, chỉ thò ra mép má và dưới cằm như
     một viền đỏ lạc chỗ — bỏ đi. */
const SUA_CHUNG = [
  /<path d="M80,122 q-6,20 8,34[^"]*"[^>]*\/>/g,
  /<path d="M80,122C76,135\.333[^"]*"[^>]*\/>/g,      // cùng mảng bóng ấy, cú pháp của hình vẽ tay khung 280x280
  /<path d="M71\.8,76C66\.726,96\.067[^"]*"[^>]*\/>/g,
  // nếp nhăn mờ ở hai góc hàm: không theo khuôn mặt khi mặt bị đổi / xoay, thành vết lạc ngoài hàm (Ông Sáu, Bà Tư)
  /<path d="M(?:80|160),150[ Cq][^"]*"[^>]*\/>/g
];
/* Cổ áo sơ mi của hai hình vẽ tay khung 280 (Bà Tư, Chú Ba): mép dưới lõm, hai đầu nhọn vểnh — trông như con dơi.
   Đổi thành hai vạt cổ tròn, mép dưới lồi (giữ nguyên chỗ nối cổ và màu). */
const SUA_CO_AO = [
  ['M120,180C112,181.333 104.667,185.333 98,192C109.333,190.667 116.667,193 120,199L120,180Z', 'M120,180C112,181.3 104.7,185.3 99,191C104,198 113,201 120,199L120,180Z'],
  ['M120,180C128,181.333 135.333,185.333 142,192C130.667,190.667 123.333,193 120,199L120,180Z', 'M120,180C128,181.3 135.3,185.3 141,191C136,198 127,201 120,199L120,180Z'],
  ['M120,182C111.333,183.333 103.333,187.667 96,195C108,193 116,195.333 120,202L120,182Z', 'M120,182C111.3,183.3 103.3,187.7 97,194C102,201 112,204 120,202L120,182Z'],
  ['M120,182C128.667,183.333 136.667,187.667 144,195C132,193 124,195.333 120,202L120,182Z', 'M120,182C128.7,183.3 136.7,187.7 143,194C138,201 128,204 120,202L120,182Z']
];
/* Chấm / cúc thừa: Chị Hoa có một cúc trắng cũ ngay dưới mặt dây chuyền; Thầy Nam có hai hàng cúc chồng nhau
   (cúc xám #d9d3c0 của hình gốc xen giữa cúc của cổ áo) — bỏ cúc thừa. */
const SUA_CHAM = {8:['<circle cx="120" cy="226" r="3" fill="#fff"'], 9:['<circle cx="120" cy="240" r="3" fill="#d9d3c0"', '<circle cx="120" cy="266" r="3" fill="#d9d3c0"']};
function suaHinhGoc(svg, i){
  SUA_CHUNG.forEach(re => { svg = svg.replace(re, ''); });
  SUA_CO_AO.forEach(([a, b]) => { svg = svg.split(a).join(b); });
  (SUA_CHAM[i] || []).forEach(k => { svg = suaBo(svg, k); });
  return SUA[i] ? SUA[i](svg) : svg;
}
